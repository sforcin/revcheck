# Raw recording format (v1)

Written by the **RevCheck Recorder** iPhone app (`mobile/`). One JSON file per drive.
This is raw sensor data in the **phone's** frame. The engine turns it into a
trip file (`trip-format.md`) the web app can open.

```json
{
  "format": "revcheck-recording",
  "version": 1,
  "started_at": "2026-10-29T19:05:12.345Z",
  "duration_s": 742.3,
  "calibration_s": 30,
  "motion_hz": 50,
  "motion_columns": ["t", "t_sensor", "ax", "ay", "az", "agx", "agy", "agz",
                     "rot_alpha", "rot_beta", "rot_gamma",
                     "rate_alpha", "rate_beta", "rate_gamma"],
  "motion": [[0.02, 81234.5521, 0.01, -0.02, 0.0, 0.12, -0.31, -9.80, ...], ...],
  "location_columns": ["t", "lat", "lon", "alt", "speed", "heading", "accuracy"],
  "location": [[0.95, 33.97, -117.33, 312.4, 0.0, -1, 4.7], ...]
}
```

Rows are arrays (not objects) to keep files small; the `*_columns` lists name each position.
Any value can be `null` if the phone didn't report it.

## Motion (about 50 rows per second)

| Column | Units | Meaning |
|---|---|---|
| `t` | s | seconds since Start, measured when the app received the sample |
| `t_sensor` | s | the sensor's own timestamp (more precise spacing, different zero) |
| `ax, ay, az` | m/s² | acceleration **without** gravity, phone axes |
| `agx, agy, agz` | m/s² | acceleration **including** gravity, phone axes |
| `rot_alpha, rot_beta, rot_gamma` | see below | phone orientation (around Z, X, Y) |
| `rate_alpha, rate_beta, rate_gamma` | deg/s | rotation rate around X, Y, Z |

## Location (about 1 row per second)

| Column | Units | Meaning |
|---|---|---|
| `t` | s | seconds since Start (from the GPS fix's own timestamp) |
| `lat, lon` | degrees | position |
| `alt` | m | altitude |
| `speed` | m/s | GPS speed (negative = unavailable) |
| `heading` | degrees | direction of travel, 0 = north, clockwise (negative = unavailable) |
| `accuracy` | m | horizontal uncertainty radius |

## Verify before trusting

Phone sensor conventions (axis signs, angle units) differ between platforms and
library versions, so **check them with a desk recording** rather than assuming:

- Phone flat on a table, screen up: which of `agx/agy/agz` reads about ±9.81, and with which sign?
- Rotate the phone a quarter turn on the table: do the `rot_*` values change by about 1.57 (radians) or 90 (degrees)?

The first 30 seconds of every drive (`calibration_s`) are recorded with the car
still, so the engine can measure gravity's direction and sensor bias.
