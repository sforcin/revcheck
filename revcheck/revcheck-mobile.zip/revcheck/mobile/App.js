import { useCallback, useEffect, useState } from "react";
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { CALIBRATION_S, useRecorder } from "./src/recorder";
import { deleteRecording, listRecordings, shareRecording } from "./src/storage";

const C = {
  bg: "#f4f3f0", card: "#fcfcfb", ink: "#0b0b0b", ink2: "#52514e", ink3: "#8a8984",
  line: "#e4e3df", accent: "#d93a2b", ok: "#1b7f4b", warn: "#a15c00",
};

const mph = (mps) => (mps == null ? "—" : Math.round(mps * 2.23694).toString());
const clock = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
const kb = (bytes) => (bytes > 1e6 ? `${(bytes / 1e6).toFixed(1)} MB` : `${Math.round(bytes / 1e3)} KB`);

export default function App() {
  return (
    <SafeAreaProvider>
      <SafeAreaView style={s.screen} edges={["top", "bottom"]}>
        <StatusBar style="dark" />
        <Recorder />
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

function Recorder() {
  const { status, error, live, start, stop } = useRecorder();
  const [recordings, setRecordings] = useState([]);

  const refresh = useCallback(() => {
    try {
      setRecordings(listRecordings());
    } catch {
      setRecordings([]);
    }
  }, []);
  useEffect(refresh, [refresh]);

  const onStop = async () => {
    const file = await stop();
    refresh();
    if (file) Alert.alert("Recording saved", "Tap it in the list below to send it to your Mac.");
  };

  const confirmDelete = (rec) =>
    Alert.alert("Delete recording?", rec.name, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => { deleteRecording(rec.uri); refresh(); } },
    ]);

  const share = async (rec) => {
    try {
      await shareRecording(rec.uri);
    } catch (e) {
      Alert.alert("Couldn't share", e.message);
    }
  };

  const recording = status === "recording";
  const calibrating = recording && live && live.elapsed < CALIBRATION_S;

  return (
    <View style={s.body}>
      <Text style={s.brand}>
        Rev<Text style={{ color: C.accent }}>Check</Text> <Text style={s.brandSub}>Recorder</Text>
      </Text>

      <View style={s.card}>
        {recording && live ? (
          <>
            <Text style={[s.banner, calibrating ? s.bannerWarn : s.bannerOk]}>
              {calibrating
                ? `Keep the car still… ${Math.ceil(CALIBRATION_S - live.elapsed)} s`
                : "Recording. Put the phone down and drive."}
            </Text>
            <View style={s.row}>
              <Stat label="Speed" value={mph(live.speed)} unit="mph" big />
              <Stat label="Time" value={clock(live.elapsed)} big />
            </View>
            <View style={s.row}>
              <Stat label="Motion" value={live.accelG.toFixed(2)} unit="g" />
              <Stat label="GPS accuracy" value={live.accuracy == null ? "—" : Math.round(live.accuracy)} unit="m" />
            </View>
            <Text style={s.small}>
              {live.nMotion.toLocaleString()} motion samples · {live.nLocation} GPS fixes
            </Text>
          </>
        ) : (
          <>
            <Text style={s.h2}>Before you drive</Text>
            <Text style={s.p}>1. Wedge the phone so it can't move (any angle is fine).</Text>
            <Text style={s.p}>2. Press Start while parked and keep still for {CALIBRATION_S} seconds.</Text>
            <Text style={s.p}>3. Keep this app open. Don't touch the phone while driving.</Text>
            <Text style={s.p}>4. Park, wait a few seconds, then press Stop.</Text>
          </>
        )}

        {error && <Text style={s.error}>{error}</Text>}

        <Pressable
          onPress={recording ? onStop : start}
          disabled={status === "starting" || status === "saving"}
          style={({ pressed }) => [s.button, recording && s.buttonStop, pressed && { opacity: 0.8 }]}
          accessibilityRole="button"
        >
          <Text style={s.buttonText}>
            {status === "starting" ? "Starting…" : status === "saving" ? "Saving…" : recording ? "Stop" : "Start recording"}
          </Text>
        </Pressable>
      </View>

      <Text style={s.h3}>Recordings</Text>
      <FlatList
        data={recordings}
        keyExtractor={(r) => r.uri}
        contentContainerStyle={{ gap: 8, paddingBottom: 24 }}
        ListEmptyComponent={<Text style={s.small}>No recordings yet.</Text>}
        renderItem={({ item }) => (
          <Pressable style={s.item} onPress={() => share(item)} onLongPress={() => confirmDelete(item)}>
            <View style={{ flex: 1 }}>
              <Text style={s.itemTitle}>{item.name.replace("revcheck-", "").replace(".json", "").replace("_", "  ")}</Text>
              <Text style={s.small}>{kb(item.size)} · tap to send, hold to delete</Text>
            </View>
            <Text style={s.share}>Send</Text>
          </Pressable>
        )}
      />
    </View>
  );
}

function Stat({ label, value, unit, big }) {
  return (
    <View style={{ flex: 1 }}>
      <Text style={s.statLabel}>{label}</Text>
      <Text style={big ? s.statBig : s.stat}>
        {value}
        {unit ? <Text style={s.statUnit}> {unit}</Text> : null}
      </Text>
    </View>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  body: { flex: 1, paddingHorizontal: 16, paddingTop: 8 },
  brand: { fontSize: 26, fontWeight: "800", color: C.ink, marginBottom: 12 },
  brandSub: { fontSize: 18, fontWeight: "600", color: C.ink2 },
  card: { backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 14, padding: 16, gap: 10 },
  h2: { fontSize: 17, fontWeight: "700", color: C.ink },
  h3: { fontSize: 13, fontWeight: "700", color: C.ink2, letterSpacing: 0.8, textTransform: "uppercase", marginTop: 20, marginBottom: 8 },
  p: { fontSize: 15, color: C.ink2, lineHeight: 21 },
  small: { fontSize: 13, color: C.ink3 },
  error: { color: C.accent, fontSize: 14 },
  banner: { fontSize: 15, fontWeight: "600", padding: 10, borderRadius: 10, overflow: "hidden" },
  bannerWarn: { backgroundColor: "#fbe6c2", color: C.warn },
  bannerOk: { backgroundColor: "#d6f0e1", color: C.ok },
  row: { flexDirection: "row", gap: 12 },
  statLabel: { fontSize: 12, color: C.ink2 },
  statBig: { fontSize: 44, fontWeight: "800", color: C.ink, fontVariant: ["tabular-nums"] },
  stat: { fontSize: 22, fontWeight: "700", color: C.ink, fontVariant: ["tabular-nums"] },
  statUnit: { fontSize: 15, fontWeight: "600", color: C.ink2 },
  button: { backgroundColor: C.accent, borderRadius: 12, paddingVertical: 16, alignItems: "center", marginTop: 4 },
  buttonStop: { backgroundColor: C.ink },
  buttonText: { color: "#fff", fontSize: 18, fontWeight: "700" },
  item: { flexDirection: "row", alignItems: "center", backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 12, padding: 12 },
  itemTitle: { fontSize: 15, fontWeight: "600", color: C.ink },
  share: { color: C.accent, fontWeight: "700", fontSize: 15 },
});
