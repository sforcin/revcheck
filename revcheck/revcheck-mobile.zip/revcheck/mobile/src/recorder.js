// Records GPS + motion sensors into memory, then saves one JSON file per drive.
// File layout: docs/recording-format.md
import { useCallback, useEffect, useRef, useState } from "react";
import * as Location from "expo-location";
import { DeviceMotion } from "expo-sensors";
import { activateKeepAwakeAsync, deactivateKeepAwake } from "expo-keep-awake";
import { saveRecording } from "./storage";

const MOTION_HZ = 50;
export const CALIBRATION_S = 30; // sit still this long at the start (see the recording guide)

const MOTION_COLUMNS = [
  "t", "t_sensor",
  "ax", "ay", "az",          // acceleration without gravity, m/s^2 (phone frame)
  "agx", "agy", "agz",       // acceleration including gravity, m/s^2 (phone frame)
  "rot_alpha", "rot_beta", "rot_gamma",     // orientation angles (as reported by expo-sensors)
  "rate_alpha", "rate_beta", "rate_gamma",  // rotation rate, deg/s
];
const LOCATION_COLUMNS = ["t", "lat", "lon", "alt", "speed", "heading", "accuracy"];

const r = (x, d = 4) => (x == null || Number.isNaN(x) ? null : Math.round(x * 10 ** d) / 10 ** d);

export function useRecorder() {
  const [status, setStatus] = useState("idle"); // idle | starting | recording | saving
  const [error, setError] = useState(null);
  const [live, setLive] = useState(null);

  // Refs hold data that changes 50 times a second without re-rendering the screen.
  const buf = useRef(null);
  const subs = useRef([]);
  const latest = useRef({ speed: null, accuracy: null, accelG: 0 });
  const timer = useRef(null);

  const cleanup = useCallback(() => {
    subs.current.forEach((s) => s?.remove());
    subs.current = [];
    clearInterval(timer.current);
    deactivateKeepAwake("recording");
  }, []);

  useEffect(() => cleanup, [cleanup]); // stop sensors if the screen goes away

  const start = useCallback(async () => {
    setError(null);
    setStatus("starting");
    try {
      const loc = await Location.requestForegroundPermissionsAsync();
      if (loc.status !== "granted") throw new Error("Location permission is needed to record speed and route.");
      const motion = await DeviceMotion.requestPermissionsAsync();
      if (motion.status !== "granted") throw new Error("Motion permission is needed to measure braking and turns.");
      if (!(await DeviceMotion.isAvailableAsync())) throw new Error("Motion sensors aren't available on this device.");

      const t0 = Date.now();
      buf.current = { startedAt: new Date(t0).toISOString(), motion: [], location: [] };
      latest.current = { speed: null, accuracy: null, accelG: 0 };
      const now = () => (Date.now() - t0) / 1000;

      DeviceMotion.setUpdateInterval(1000 / MOTION_HZ);
      subs.current.push(
        DeviceMotion.addListener((m) => {
          const a = m.acceleration;
          const g = m.accelerationIncludingGravity;
          const rot = m.rotation;
          const rate = m.rotationRate;
          buf.current.motion.push([
            r(now(), 3), r(g?.timestamp, 4),
            r(a?.x), r(a?.y), r(a?.z),
            r(g?.x), r(g?.y), r(g?.z),
            r(rot?.alpha), r(rot?.beta), r(rot?.gamma),
            r(rate?.alpha, 3), r(rate?.beta, 3), r(rate?.gamma, 3),
          ]);
          if (a) latest.current.accelG = Math.hypot(a.x, a.y, a.z) / 9.80665;
        })
      );

      subs.current.push(
        await Location.watchPositionAsync(
          { accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 0 },
          (p) => {
            const c = p.coords;
            buf.current.location.push([
              r((p.timestamp - t0) / 1000, 3), r(c.latitude, 7), r(c.longitude, 7), r(c.altitude, 1),
              r(c.speed, 2), r(c.heading, 1), r(c.accuracy, 1),
            ]);
            latest.current.speed = c.speed != null && c.speed >= 0 ? c.speed : null;
            latest.current.accuracy = c.accuracy;
          }
        )
      );

      await activateKeepAwakeAsync("recording"); // the screen must stay on in Expo Go
      // Refresh the on-screen numbers 4 times a second (not 50).
      timer.current = setInterval(() => {
        setLive({
          elapsed: now(),
          speed: latest.current.speed,
          accuracy: latest.current.accuracy,
          accelG: latest.current.accelG,
          nMotion: buf.current.motion.length,
          nLocation: buf.current.location.length,
        });
      }, 250);
      setStatus("recording");
    } catch (e) {
      cleanup();
      setError(e.message);
      setStatus("idle");
    }
  }, [cleanup]);

  const stop = useCallback(async () => {
    cleanup();
    setStatus("saving");
    try {
      const b = buf.current;
      const recording = {
        format: "revcheck-recording",
        version: 1,
        started_at: b.startedAt,
        duration_s: r(b.motion.at(-1)?.[0] ?? 0, 1),
        calibration_s: CALIBRATION_S,
        device: { platform: "ios", source: "RevCheck Recorder (Expo)" },
        motion_hz: MOTION_HZ,
        motion_columns: MOTION_COLUMNS,
        motion: b.motion,
        location_columns: LOCATION_COLUMNS,
        location: b.location,
      };
      const file = await saveRecording(recording);
      setLive(null);
      return file;
    } catch (e) {
      setError(`Couldn't save the recording: ${e.message}`);
      return null;
    } finally {
      buf.current = null;
      setStatus("idle");
    }
  }, [cleanup]);

  return { status, error, live, start, stop };
}
