// Saved recordings live in the app's documents folder, one JSON file each.
import { Directory, File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";

function recordingsDir() {
  const dir = new Directory(Paths.document, "recordings");
  if (!dir.exists) dir.create();
  return dir;
}

// 2026-10-29T19:05:12.345Z -> revcheck-2026-10-29_19-05-12.json
function fileName(iso) {
  return `revcheck-${iso.slice(0, 19).replace("T", "_").replace(/:/g, "-")}.json`;
}

export async function saveRecording(recording) {
  const file = new File(recordingsDir(), fileName(recording.started_at));
  file.create({ overwrite: true });
  await file.write(JSON.stringify(recording));
  return file;
}

export function listRecordings() {
  return recordingsDir()
    .list()
    .filter((f) => f instanceof File && f.name.endsWith(".json"))
    .map((f) => ({ uri: f.uri, name: f.name, size: f.size, modified: f.modificationTime }))
    .sort((a, b) => b.name.localeCompare(a.name)); // names start with the date, newest first
}

export function deleteRecording(uri) {
  new File(uri).delete();
}

// Opens the iOS share sheet so you can AirDrop the file to your Mac.
export async function shareRecording(uri) {
  if (!(await Sharing.isAvailableAsync())) throw new Error("Sharing isn't available on this device.");
  await Sharing.shareAsync(uri, { mimeType: "application/json", UTI: "public.json", dialogTitle: "Send recording" });
}
