# RevCheck Recorder (iPhone)

Records GPS and motion sensors during a drive and saves one JSON file per drive
(format: `../docs/recording-format.md`). Send a recording to your Mac with AirDrop,
then feed it to the engine.

## Run it on your iPhone (no Xcode needed)

1. Install **Expo Go** from the App Store on your iPhone.
2. On your Mac (Node.js 20+), with the Mac and iPhone on the **same Wi-Fi**:

   ```bash
   cd mobile
   npm install
   npx expo start
   ```

3. Scan the QR code in the terminal with the iPhone **Camera** app. It opens in Expo Go.
4. Allow location and motion access when asked.

If the phone can't connect (some school or office networks block it), run
`npx expo start --tunnel` instead.

## Limits of this version

- **Keep the app open with the screen on.** It stops recording if you switch apps or
  lock the phone (the app keeps the screen awake while recording).
- No OBD-II yet. Bluetooth needs a "development build" instead of Expo Go, which is the next step.

## Files

```
App.js            the screen: Start/Stop, live readouts, list of recordings
src/recorder.js   subscribes to GPS + motion sensors and buffers the samples
src/storage.js    saves, lists, deletes and shares recording files
app.json          app name, bundle id, permission messages
```
